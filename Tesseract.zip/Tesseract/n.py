import cv2
import imutils
from skimage.metrics import structural_similarity as ssim

imageA = cv2.imread("medOriginal2.jpg")
imageB = cv2.imread("medDefected2.jpg")

imageA = cv2.resize(imageA,(1000,500),interpolation=cv2.INTER_LINEAR)
imageB = cv2.resize(imageB,(1000,500),interpolation=cv2.INTER_LINEAR)

grayA = cv2.cvtColor(imageA, cv2.COLOR_BGR2GRAY)
grayB = cv2.cvtColor(imageB, cv2.COLOR_BGR2GRAY)

(score, diff) = ssim(grayA, grayB, full=True)
diff = (diff*255).astype("uint8")

thresh = cv2.threshold(diff, 0, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)[1]

cnts = cv2.findContours(thresh.copy(), cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
cnts = imutils.grab_contours(cnts)

for c in cnts:
    (x, y, w, h) = cv2.boundingRect(c)
    #cv2.rectangle(imageA, (x, y), (x+w, y+h), (0, 0, 255), 1)
    cv2.rectangle(imageB, (x, y), (x+w, y+h), (0, 0, 255), 1)

    cv2.imshow('img', imageB)
    cv2.waitKey(0)