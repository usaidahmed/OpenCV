import numpy as np
import cv2

rawImage = cv2.imread('medOriginal2.jpg')
cv2.imshow('Original Image',rawImage)

gray = cv2.cvtColor(rawImage, cv2.COLOR_BGR2GRAY)
cv2.imshow('HSV Image',gray)

#hue ,saturation ,value = cv2.split(gray)
cv2.imshow('Saturation Image',gray)

retval, thresholded = cv2.threshold(gray, 50, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
cv2.imshow('Thresholded Image',thresholded)

#canny = cv2.Canny(thresholded, 200 , 200)
#cv2.imshow('canny',canny)

contours, hierarchy = cv2.findContours(thresholded, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

contour_list = []
for contour in contours:
    area = cv2.contourArea(contour)
    if area > 2:
        contour_list.append(contour)

cv2.drawContours(rawImage, contour_list,  -1, (255,0,0), 2)
cv2.namedWindow('Objects Detected', cv2.WINDOW_NORMAL)
cv2.imshow('Objects Detected',rawImage)
cv2.waitKey(0)