# import the necessary packages
from skimage.metrics import structural_similarity as compare_ssim
import argparse
import imutils
import cv2

# load the two input images
imageA = cv2.imread("sports balls.png")
imageB = cv2.imread("blue lines.png")

# convert the images to grayscale
grayA = cv2.cvtColor(imageA, cv2.COLOR_BGR2GRAY)
grayB = cv2.cvtColor(imageB, cv2.COLOR_BGR2GRAY)

(score, diff) = compare_ssim(grayA, grayB, full=True)
diff = (diff * 255).astype("uint8")
print("SSIM: {}".format(score))

thresh = cv2.threshold(diff, 0, 255,
                       cv2.THRESH_BINARY_INV | cv2.THRESH_OTSU)[1]

def display_window(str0, str1 ,str2 ,str3 , img0 ,img1 ,img2 , img3):
    cv2.namedWindow(str0, cv2.WINDOW_NORMAL)
    cv2.imshow(str0, img0)
    cv2.namedWindow(str1, cv2.WINDOW_NORMAL)
    cv2.imshow(str1, img1)
    cv2.namedWindow(str2, cv2.WINDOW_NORMAL)
    cv2.imshow(str2, img2)
    cv2.namedWindow(str3, cv2.WINDOW_NORMAL)
    cv2.imshow(str3, img3)
    cv2.waitKey(0)

display_window("Orignal","Modified", "Diff", "Thresh" ,imageA, imageB, diff, thresh)



