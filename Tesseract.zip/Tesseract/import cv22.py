import cv2
import numpy as np

img = cv2.imread('medOriginal2.jpg')
#img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
# threshold image
ret, threshed_img = cv2.threshold(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY),
                100, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
# find contours and get the external one

contours, hier = cv2.findContours(threshed_img, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

# with each contour, draw boundingRect in green
for c in contours:
    # get the bounding rect
    x, y, w, h = cv2.boundingRect(c)
    # draw a green rectangle to visualize the bounding rect
    cv2.rectangle(img, (x, y), (x+w, y+h), (0, 255, 0), 3)


print(len(contours))
cv2.drawContours(img, contours, -1, (0, 0, 0), 1)
cv2.namedWindow('contours', cv2.WINDOW_NORMAL)
cv2.imshow("contours", img)

while True:
    key = cv2.waitKey(1)
    if key == 27: #ESC key to break
        break

cv2.destroyAllWindows()