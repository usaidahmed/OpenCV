import cv2
import pytesseract
from pytesseract import Output
pytesseract.pytesseract.tesseract_cmd = 'C:/Program Files/Tesseract-OCR/tesseract.exe'

img = cv2.imread('med_image.jpg')

text = pytesseract.image_to_string(img, lang = 'eng')

print(text)