import cv2
import numpy as np

img = cv2.imread('medOriginal2.jpg')
ref_img = cv2.imread('medDefected2.jpg')

#img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
#ref_img = cv2.cvtColor(ref_img, cv2.COLOR_BGR2GRAY)


retval, thresholded = cv2.threshold(img, 150, 255, cv2.THRESH_BINARY)
cv2.namedWindow('min', cv2.WINDOW_NORMAL)
cv2.imshow("min", thresholded)
retval, thresh = cv2.threshold(ref_img, 50, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

#canny = cv2.Canny(thresholded, 200, 200)

contours, hier = cv2.findContours(thresholded, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

for c in contours:
    # get the bounding rect
    x, y, w, h = cv2.boundingRect(c)
    # draw a green rectangle to visualize the bounding rect
    cv2.rectangle(ref_img, (x, y), (x+w, y+h), (255, 0, 0), 1)

print(len(contours))
cv2.drawContours(ref_img, contours, -1, (0, 0, 0), 1)
cv2.namedWindow('contours', cv2.WINDOW_NORMAL)
cv2.imshow("contours", ref_img)

# # cv2.namedWindow('img', cv2.WINDOW_NORMAL)
# # cv2.imshow('img', combine)
cv2.waitKey(0)


